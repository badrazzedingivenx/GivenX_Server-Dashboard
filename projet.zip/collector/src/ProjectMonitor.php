<?php
/*
Rôle du fichier :
Ce fichier contient la logique de surveillance des projets applicatifs.

Ce qu’il contient :
- la lecture des projets en base via l’API n’est pas encore faite ici
- la détection d’un projet par process_name
- le calcul simplifié du CPU et de la RAM du projet
- la détermination du statut running/stopped

Pourquoi il existe :
Le projet doit surveiller les applications elles-mêmes, pas seulement le serveur global.

Comment il s’intègre dans le projet :
La classe Collector utilisera ProjectMonitor pour construire et envoyer les métriques
des projets vers le backend.
*/

class ProjectMonitor
{
    public function inspectProject(array $project): array
    {
        $processName = trim((string)($project['process_name'] ?? ''));
        $projectPort = isset($project['port']) ? (int)$project['port'] : null;

        if ($processName === '') {
            return [
                'cpu_usage' => 0.0,
                'ram_usage_mb' => 0.0,
                'status' => 'unknown',
                'pid' => null,
                'port_detected' => $projectPort,
                'collected_at' => date('Y-m-d H:i:s')
            ];
        }

        $command = "ps -eo pid,pcpu,rss,args --no-headers | grep -i " . escapeshellarg($processName) . " | grep -v grep";
        $output = shell_exec($command);

        if (!$output || trim($output) === '') {
            return [
                'cpu_usage' => 0.0,
                'ram_usage_mb' => 0.0,
                'status' => 'stopped',
                'pid' => null,
                'port_detected' => $projectPort,
                'collected_at' => date('Y-m-d H:i:s')
            ];
        }

        $lines = preg_split('/\r\n|\r|\n/', trim($output));
        $totalCpu = 0.0;
        $totalRamKb = 0.0;
        $firstPid = null;

        foreach ($lines as $line) {
            $line = trim($line);

            if ($line === '') {
                continue;
            }

            $parts = preg_split('/\s+/', $line, 4);

            $pid = isset($parts[0]) ? (int)$parts[0] : null;
            $pcpu = isset($parts[1]) ? (float)$parts[1] : 0.0;
            $rssKb = isset($parts[2]) ? (float)$parts[2] : 0.0;

            if ($firstPid === null && $pid !== null) {
                $firstPid = $pid;
            }

            $totalCpu += $pcpu;
            $totalRamKb += $rssKb;
        }

        return [
            'cpu_usage' => round($totalCpu, 2),
            'ram_usage_mb' => round($totalRamKb / 1024, 2),
            'status' => 'running',
            'pid' => $firstPid,
            'port_detected' => $projectPort,
            'collected_at' => date('Y-m-d H:i:s')
        ];
    }
}
