<?php
/*
Rôle du fichier :
Ce fichier contient le contrôleur des alertes.

Ce qu’il contient :
- la liste des alertes de l’utilisateur connecté
- une génération minimale d’alertes à partir des dernières métriques

Pourquoi il existe :
Le cahier des charges exige des alertes automatiques.

Comment il s’intègre dans le projet :
Le backend peut générer des alertes simples et le frontend peut les afficher.
*/

class AlertController
{
    public function index(array $params = []): void
    {
        $user = Auth::requireAuth();
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare("
            SELECT
                id,
                user_id,
                server_id,
                project_id,
                type,
                severity,
                message,
                status,
                created_at,
                resolved_at
            FROM alerts
            WHERE user_id = :user_id
            ORDER BY created_at DESC
            LIMIT 100
        ");

        $stmt->execute([
            'user_id' => $user['id']
        ]);

        $alerts = $stmt->fetchAll();

        Response::json([
            'success' => true,
            'message' => 'Liste des alertes récupérée avec succès',
            'data' => [
                'alerts' => $alerts
            ]
        ]);
    }

    public function generate(array $params = []): void
    {
        $user = Auth::requireAuth();
        $pdo = Database::getConnection();

        $createdAlerts = [];

        $serverStmt = $pdo->prepare("
            SELECT s.id, s.name
            FROM servers s
            WHERE s.user_id = :user_id
        ");
        $serverStmt->execute(['user_id' => $user['id']]);
        $servers = $serverStmt->fetchAll();

        foreach ($servers as $server) {
            $metricStmt = $pdo->prepare("
                SELECT *
                FROM server_metrics
                WHERE server_id = :server_id
                ORDER BY collected_at DESC
                LIMIT 1
            ");
            $metricStmt->execute(['server_id' => $server['id']]);
            $metric = $metricStmt->fetch();

            if (!$metric) {
                continue;
            }

            if ((float)$metric['cpu_usage'] >= 85) {
                $createdAlerts[] = $this->createAlertIfNotOpen(
                    $pdo,
                    $user['id'],
                    $server['id'],
                    null,
                    'cpu_high',
                    'warning',
                    "CPU élevé sur le serveur {$server['name']} : {$metric['cpu_usage']}%"
                );
            }

            if ((float)$metric['ram_usage'] >= 85) {
                $createdAlerts[] = $this->createAlertIfNotOpen(
                    $pdo,
                    $user['id'],
                    $server['id'],
                    null,
                    'ram_high',
                    'warning',
                    "RAM élevée sur le serveur {$server['name']} : {$metric['ram_usage']}%"
                );
            }
        }

        $projectStmt = $pdo->prepare("
            SELECT p.id, p.name
            FROM projects p
            WHERE p.user_id = :user_id
        ");
        $projectStmt->execute(['user_id' => $user['id']]);
        $projects = $projectStmt->fetchAll();

        foreach ($projects as $project) {
            $metricStmt = $pdo->prepare("
                SELECT *
                FROM project_metrics
                WHERE project_id = :project_id
                ORDER BY collected_at DESC
                LIMIT 1
            ");
            $metricStmt->execute(['project_id' => $project['id']]);
            $metric = $metricStmt->fetch();

            if (!$metric) {
                continue;
            }

            if (($metric['status'] ?? 'unknown') === 'stopped') {
                $createdAlerts[] = $this->createAlertIfNotOpen(
                    $pdo,
                    $user['id'],
                    null,
                    $project['id'],
                    'process_stopped',
                    'critical',
                    "Le projet {$project['name']} est arrêté"
                );
            }
        }

        $createdAlerts = array_values(array_filter($createdAlerts));

        Response::json([
            'success' => true,
            'message' => 'Génération des alertes terminée',
            'data' => [
                'created_alerts' => $createdAlerts,
                'count' => count($createdAlerts)
            ]
        ]);
    }

    public function resolve(array $params): void
    {
        $user = Auth::requireAuth();
        $alertId = isset($params['id']) ? (int)$params['id'] : 0;

        if ($alertId <= 0) {
            Response::json([
                'success' => false,
                'message' => 'Identifiant alerte invalide'
            ], 422);
        }

        $pdo = Database::getConnection();

        $stmt = $pdo->prepare("
            UPDATE alerts
            SET status = 'resolved', resolved_at = NOW()
            WHERE id = :id AND user_id = :user_id
        ");

        $stmt->execute([
            'id' => $alertId,
            'user_id' => $user['id']
        ]);

        Response::json([
            'success' => true,
            'message' => 'Alerte résolue avec succès'
        ]);
    }

    private function createAlertIfNotOpen(
        PDO $pdo,
        int $userId,
        ?int $serverId,
        ?int $projectId,
        string $type,
        string $severity,
        string $message
    ): ?array {
        $stmt = $pdo->prepare("
            SELECT id
            FROM alerts
            WHERE user_id = :user_id
              AND type = :type
              AND status = 'open'
              AND (
                    (server_id <=> :server_id)
                AND (project_id <=> :project_id)
              )
            LIMIT 1
        ");

        $stmt->execute([
            'user_id' => $userId,
            'type' => $type,
            'server_id' => $serverId,
            'project_id' => $projectId
        ]);

        $existing = $stmt->fetch();

        if ($existing) {
            return null;
        }

        $insert = $pdo->prepare("
            INSERT INTO alerts (
                user_id,
                server_id,
                project_id,
                type,
                severity,
                message,
                status
            ) VALUES (
                :user_id,
                :server_id,
                :project_id,
                :type,
                :severity,
                :message,
                'open'
            )
        ");

        $insert->execute([
            'user_id' => $userId,
            'server_id' => $serverId,
            'project_id' => $projectId,
            'type' => $type,
            'severity' => $severity,
            'message' => $message
        ]);

        return [
            'id' => (int)$pdo->lastInsertId(),
            'type' => $type,
            'severity' => $severity,
            'message' => $message
        ];
    }
}
