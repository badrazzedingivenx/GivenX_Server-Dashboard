
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
/*
Rôle du fichier :
Ce fichier est le point d’entrée principal du backend PHP.

Toutes les requêtes HTTP vers l’API passent par ce fichier.

Ce qu’il fait :
- configure les headers CORS pour React
- charge les classes core
- charge les services
- charge les contrôleurs
- charge les routes
- exécute le routeur

Pourquoi il existe :
Il centralise l’exécution de l’API REST.

Comment il s’intègre dans le projet :
Le frontend React, le collecteur Linux et les appels curl passent par ce fichier.
*/

header("Content-Type: application/json");

header("Access-Control-Allow-Origin: http://localhost:3000");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/Request.php';
require_once __DIR__ . '/../app/core/Response.php';
require_once __DIR__ . '/../app/core/Router.php';
require_once __DIR__ . '/../app/core/Auth.php';

require_once __DIR__ . '/../app/services/SystemLogService.php';
require_once __DIR__ . '/../app/services/UserActionLogger.php';
require_once __DIR__ . '/../app/services/AlertEngine.php';

require_once __DIR__ . '/../app/controllers/HealthController.php';
require_once __DIR__ . '/../app/controllers/AuthController.php';
require_once __DIR__ . '/../app/controllers/ServerController.php';
require_once __DIR__ . '/../app/controllers/ProjectController.php';
require_once __DIR__ . '/../app/controllers/MetricController.php';
require_once __DIR__ . '/../app/controllers/AlertController.php';
require_once __DIR__ . '/../app/controllers/AlertRuleController.php';
require_once __DIR__ . '/../app/controllers/CollectorController.php';
require_once __DIR__ . '/../app/controllers/CollectorProjectController.php';
require_once __DIR__ . '/../app/controllers/AdminController.php';
require_once __DIR__ . '/../app/controllers/LogController.php';

$router = new Router();

require_once __DIR__ . '/../app/routes/api.php';

$method = Request::method();
$uri = Request::uri();

$router->dispatch($method, $uri);
