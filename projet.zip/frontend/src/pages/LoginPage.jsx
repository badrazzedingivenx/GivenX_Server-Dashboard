/*
Rôle du fichier :
Cette page permet à l’utilisateur de se connecter.

Ce qu’il contient :
- un formulaire email / mot de passe
- l’appel API de connexion

Pourquoi il existe :
Le dashboard doit être protégé par authentification.

Comment il s’intègre dans le projet :
C’est la page d’entrée publique de l’application React.
*/

import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function LoginPage() {
  const { login } = useAuth();
  const [form, setForm] = useState({
    email: "doha@test.com",
    password: "secret123",
  });
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await login(form.email, form.password);
      window.location.href = "/";
    } catch (err) {
      setError("Connexion impossible");
    }
  };

  return (
    <div style={styles.wrapper}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h2>Connexion</h2>
        <input
          style={styles.input}
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <input
          style={styles.input}
          type="password"
          placeholder="Mot de passe"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
        />
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.button} type="submit">
          Se connecter
        </button>
      </form>
    </div>
  );
}

const styles = {
  wrapper: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "#e2e8f0",
  },
  form: {
    background: "#fff",
    padding: "32px",
    borderRadius: "12px",
    width: "360px",
    display: "grid",
    gap: "12px",
  },
  input: {
    padding: "12px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
  },
  button: {
    background: "#2563eb",
    color: "#fff",
    border: "none",
    padding: "12px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  error: {
    color: "#dc2626",
  },
};
