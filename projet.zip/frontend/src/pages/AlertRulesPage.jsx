/*
Rôle du fichier :
Cette page permet de gérer les règles d’alertes de l’utilisateur.

Ce qu’il contient :
- affichage de la liste des règles
- formulaire de création
- formulaire de modification
- suppression d’une règle

Pourquoi il existe :
Le projet doit permettre de personnaliser les seuils et comportements d’alertes.

Comment il s’intègre dans le projet :
Cette page est accessible depuis l’interface React et communique avec l’API REST.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";

const defaultForm = {
  server_id: "",
  project_id: "",
  rule_type: "cpu_high",
  threshold_value: "",
  severity: "warning",
  cooldown_minutes: 10,
  is_active: 1,
};

export default function AlertRulesPage() {
  const [rules, setRules] = useState([]);
  const [form, setForm] = useState(defaultForm);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    try {
      const res = await client.get("/api/alert-rules");
      setRules(res.data.data.rules || []);
    } catch (error) {
      console.error("Erreur chargement règles :", error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setForm(defaultForm);
    setEditingId(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      server_id: form.server_id === "" ? null : Number(form.server_id),
      project_id: form.project_id === "" ? null : Number(form.project_id),
      rule_type: form.rule_type,
      threshold_value:
        form.threshold_value === "" ? null : Number(form.threshold_value),
      severity: form.severity,
      cooldown_minutes: Number(form.cooldown_minutes),
      is_active: Number(form.is_active),
    };

    try {
      if (editingId) {
        await client.put(`/api/alert-rules/${editingId}`, payload);
      } else {
        await client.post("/api/alert-rules", payload);
      }

      resetForm();
      loadRules();
    } catch (error) {
      console.error("Erreur sauvegarde règle :", error);
      alert("Impossible d’enregistrer la règle.");
    }
  };

  const handleEdit = (rule) => {
    setEditingId(rule.id);
    setForm({
      server_id: rule.server_id ?? "",
      project_id: rule.project_id ?? "",
      rule_type: rule.rule_type ?? "cpu_high",
      threshold_value: rule.threshold_value ?? "",
      severity: rule.severity ?? "warning",
      cooldown_minutes: rule.cooldown_minutes ?? 10,
      is_active: rule.is_active ?? 1,
    });
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Supprimer cette règle d’alerte ?")) {
      return;
    }

    try {
      await client.delete(`/api/alert-rules/${id}`);
      loadRules();
    } catch (error) {
      console.error("Erreur suppression règle :", error);
      alert("Impossible de supprimer la règle.");
    }
  };

  return (
    <MainLayout>
      <h1 style={styles.title}>Règles d’alertes</h1>

      <div style={styles.container}>
        <div style={styles.formCard}>
          <h2>{editingId ? "Modifier une règle" : "Créer une règle"}</h2>

          <form onSubmit={handleSubmit} style={styles.form}>
            <label style={styles.label}>
              Type de règle
              <select
                name="rule_type"
                value={form.rule_type}
                onChange={handleChange}
                style={styles.input}
              >
                <option value="cpu_high">CPU élevé</option>
                <option value="ram_high">RAM élevée</option>
                <option value="server_down">Serveur indisponible</option>
                <option value="process_stopped">Processus arrêté</option>
              </select>
            </label>

            <label style={styles.label}>
              Server ID
              <input
                type="number"
                name="server_id"
                value={form.server_id}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: 2"
              />
            </label>

            <label style={styles.label}>
              Project ID
              <input
                type="number"
                name="project_id"
                value={form.project_id}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: 2"
              />
            </label>

            <label style={styles.label}>
              Seuil
              <input
                type="number"
                step="0.01"
                name="threshold_value"
                value={form.threshold_value}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: 85"
              />
            </label>

            <label style={styles.label}>
              Sévérité
              <select
                name="severity"
                value={form.severity}
                onChange={handleChange}
                style={styles.input}
              >
                <option value="warning">warning</option>
                <option value="critical">critical</option>
              </select>
            </label>

            <label style={styles.label}>
              Cooldown (minutes)
              <input
                type="number"
                name="cooldown_minutes"
                value={form.cooldown_minutes}
                onChange={handleChange}
                style={styles.input}
              />
            </label>

            <label style={styles.label}>
              Actif
              <select
                name="is_active"
                value={form.is_active}
                onChange={handleChange}
                style={styles.input}
              >
                <option value={1}>Oui</option>
                <option value={0}>Non</option>
              </select>
            </label>

            <div style={styles.actions}>
              <button type="submit" style={styles.primaryButton}>
                {editingId ? "Mettre à jour" : "Créer"}
              </button>

              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  style={styles.secondaryButton}
                >
                  Annuler
                </button>
              )}
            </div>
          </form>
        </div>

        <div style={styles.listCard}>
          <h2>Liste des règles</h2>

          {loading ? (
            <div>Chargement...</div>
          ) : rules.length === 0 ? (
            <div>Aucune règle enregistrée.</div>
          ) : (
            <div style={styles.ruleList}>
              {rules.map((rule) => (
                <div key={rule.id} style={styles.ruleItem}>
                  <div style={styles.ruleHeader}>
                    <strong>{rule.rule_type}</strong>
                    <span style={rule.is_active ? styles.activeBadge : styles.inactiveBadge}>
                      {rule.is_active ? "Active" : "Inactive"}
                    </span>
                  </div>

                  <div style={styles.ruleRow}>ID : {rule.id}</div>
                  <div style={styles.ruleRow}>Server ID : {rule.server_id ?? "-"}</div>
                  <div style={styles.ruleRow}>Project ID : {rule.project_id ?? "-"}</div>
                  <div style={styles.ruleRow}>Seuil : {rule.threshold_value ?? "-"}</div>
                  <div style={styles.ruleRow}>Sévérité : {rule.severity}</div>
                  <div style={styles.ruleRow}>Cooldown : {rule.cooldown_minutes} min</div>

                  <div style={styles.actions}>
                    <button
                      onClick={() => handleEdit(rule)}
                      style={styles.primaryButton}
                    >
                      Modifier
                    </button>
                    <button
                      onClick={() => handleDelete(rule.id)}
                      style={styles.dangerButton}
                    >
                      Supprimer
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}

const styles = {
  title: {
    marginBottom: "20px",
  },
  container: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: "20px",
    alignItems: "start",
  },
  formCard: {
    background: "#fff",
    borderRadius: "12px",
    padding: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  listCard: {
    background: "#fff",
    borderRadius: "12px",
    padding: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  form: {
    display: "grid",
    gap: "12px",
  },
  label: {
    display: "grid",
    gap: "6px",
    color: "#334155",
  },
  input: {
    padding: "10px",
    borderRadius: "8px",
    border: "1px solid #cbd5e1",
  },
  actions: {
    display: "flex",
    gap: "10px",
    marginTop: "8px",
  },
  primaryButton: {
    background: "#2563eb",
    color: "#fff",
    border: "none",
    padding: "10px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  secondaryButton: {
    background: "#64748b",
    color: "#fff",
    border: "none",
    padding: "10px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  dangerButton: {
    background: "#dc2626",
    color: "#fff",
    border: "none",
    padding: "10px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  ruleList: {
    display: "grid",
    gap: "12px",
  },
  ruleItem: {
    border: "1px solid #e2e8f0",
    borderRadius: "12px",
    padding: "16px",
    background: "#f8fafc",
  },
  ruleHeader: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "10px",
  },
  ruleRow: {
    marginBottom: "6px",
    color: "#334155",
  },
  activeBadge: {
    background: "#dcfce7",
    color: "#166534",
    padding: "4px 10px",
    borderRadius: "999px",
    fontSize: "12px",
    fontWeight: "bold",
  },
  inactiveBadge: {
    background: "#fee2e2",
    color: "#b91c1c",
    padding: "4px 10px",
    borderRadius: "999px",
    fontSize: "12px",
    fontWeight: "bold",
  },
};
