import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";

export default function AdminUsersPage() {

  const [users,setUsers] = useState([]);

  useEffect(()=>{
    loadUsers();
  },[]);

  const loadUsers = async () => {
    const res = await client.get("/api/admin/users");
    setUsers(res.data.data.users);
  };

  const blockUser = async (id) => {

    await client.put(`/api/admin/users/${id}/block`);
    loadUsers();

  };

  const deleteUser = async (id) => {

    if(!window.confirm("Supprimer cet utilisateur ?")) return;

    await client.delete(`/api/admin/users/${id}`);
    loadUsers();

  };

  return (

    <MainLayout>

      <h1>Gestion des utilisateurs</h1>

      <table style={{width:"100%",marginTop:20}}>

        <thead>

          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>

        </thead>

        <tbody>

        {users.map(user=>(
          <tr key={user.id}>

            <td>{user.id}</td>
            <td>{user.name}</td>
            <td>{user.email}</td>
            <td>{user.role}</td>
            <td>{user.status}</td>

            <td>

              <button onClick={()=>blockUser(user.id)}>
                Bloquer
              </button>

              <button
                onClick={()=>deleteUser(user.id)}
                style={{marginLeft:10}}
              >
                Supprimer
              </button>

            </td>

          </tr>
        ))}

        </tbody>

      </table>

    </MainLayout>

  );
}
