/*
Rôle du fichier :
Cette page affiche toutes les alertes de l’utilisateur connecté.

Ce qu’il contient :
- le chargement des alertes depuis l’API
- un bouton pour régénérer les alertes
- un affichage sous forme de liste stylée

Pourquoi il existe :
Le cahier des charges impose une gestion des alertes automatiques.

Comment il s’intègre dans le projet :
Elle est accessible depuis le menu latéral et complète le dashboard principal.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";
import AlertList from "../components/AlertList";

export default function AlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      const res = await client.get("/api/alerts");
      setAlerts(res.data.data.alerts || []);
    } catch (error) {
      console.error("Erreur chargement alertes :", error);
    } finally {
      setLoading(false);
    }
  };

  const generateAlerts = async () => {
    try {
      await client.post("/api/alerts/generate");
      await loadAlerts();
    } catch (error) {
      console.error("Erreur génération alertes :", error);
    }
  };

  return (
    <MainLayout>
      <div style={styles.header}>
        <h1 style={{ margin: 0 }}>Alertes</h1>
        <button style={styles.button} onClick={generateAlerts}>
          Régénérer les alertes
        </button>
      </div>

      {loading ? (
        <div style={styles.info}>Chargement des alertes...</div>
      ) : (
        <AlertList alerts={alerts} />
      )}
    </MainLayout>
  );
}

const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "20px",
  },
  button: {
    background: "#2563eb",
    color: "#fff",
    border: "none",
    padding: "10px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  info: {
    background: "#fff",
    padding: "16px",
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
};
