/*
Rôle du fichier :
Cette page affiche le tableau de bord principal du projet.

Ce qu’il contient :
- les cartes KPI
- le graphique historique serveur
- les alertes récentes
- un rechargement automatique périodique

Pourquoi il existe :
C’est la page principale de supervision présentée à l’utilisateur.

Comment il s’intègre dans le projet :
Elle consomme les endpoints backend de métriques et d’alertes.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import StatCard from "../components/StatCard";
import AlertList from "../components/AlertList";
import ServerChart from "../components/ServerChart";
import MainLayout from "../layout/MainLayout";

export default function DashboardPage() {
  const [latest, setLatest] = useState(null);
  const [history, setHistory] = useState([]);
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    loadData();

    const interval = setInterval(() => {
      loadData();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const latestRes = await client.get("/api/servers/2/metrics/latest");
      const historyRes = await client.get("/api/servers/2/metrics/history");
      const alertsRes = await client.get("/api/alerts");

      setLatest(latestRes.data.data.metric);
      setHistory(historyRes.data.data.metrics || []);
      setAlerts(alertsRes.data.data.alerts || []);
    } catch (error) {
      console.error("Erreur dashboard :", error);
    }
  };

  return (
    <MainLayout>
      <h1 style={styles.title}>Dashboard</h1>

      <div style={styles.grid}>
        <StatCard title="CPU" value={latest ? `${latest.cpu_usage}%` : "..."} />
        <StatCard title="RAM" value={latest ? `${latest.ram_usage}%` : "..."} />
        <StatCard title="Disque" value={latest ? `${latest.disk_usage}%` : "..."} />
        <StatCard title="Processus" value={latest ? latest.process_count : "..."} />
      </div>

      <div style={styles.section}>
        <ServerChart data={history} />
      </div>

      <div style={styles.section}>
        <h2>Alertes</h2>
        <AlertList alerts={alerts} />
      </div>
    </MainLayout>
  );
}

const styles = {
  title: {
    marginBottom: "20px",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
    gap: "16px",
    marginBottom: "24px",
  },
  section: {
    marginBottom: "24px",
  },
};
