/*
Rôle du fichier :
Cette page affiche le dashboard administrateur.

Ce qu’il contient :
- le chargement des statistiques globales de la plateforme
- l’affichage des KPI administrateur sous forme de cartes

Pourquoi il existe :
Le cahier des charges demande un espace administrateur distinct permettant
de superviser globalement la plateforme.

Comment il s’intègre dans le projet :
Elle est accessible uniquement aux utilisateurs ayant le rôle admin.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";
import StatCard from "../components/StatCard";

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const res = await client.get("/api/admin/dashboard");
      setStats(res.data.data);
    } catch (error) {
      console.error("Erreur chargement dashboard admin :", error);
    }
  };

  return (
    <MainLayout>
      <h1 style={styles.title}>Dashboard Administrateur</h1>

      {!stats ? (
        <div style={styles.info}>Chargement des statistiques administrateur...</div>
      ) : (
        <div style={styles.grid}>
          <StatCard title="Utilisateurs" value={stats.users_count} />
          <StatCard title="Serveurs" value={stats.servers_count} />
          <StatCard title="Projets" value={stats.projects_count} />
          <StatCard title="Alertes" value={stats.alerts_count} />
        </div>
      )}
    </MainLayout>
  );
}

const styles = {
  title: {
    marginBottom: "20px",
  },
  info: {
    background: "#fff",
    padding: "16px",
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
    gap: "16px",
  },
};

