import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";

export default function LogsPage(){

  const [logs,setLogs] = useState([]);

  useEffect(()=>{
    loadLogs();
  },[]);

  const loadLogs = async () => {

    const res = await client.get("/api/logs/users");

    setLogs(res.data.data.logs);

  };

  return(

    <MainLayout>

      <h1>Logs utilisateurs</h1>

      <table style={{width:"100%",marginTop:20}}>

        <thead>
          <tr>
            <th>Utilisateur</th>
            <th>Action</th>
            <th>Détails</th>
            <th>Date</th>
          </tr>
        </thead>

        <tbody>

        {logs.map(log=>(
          <tr key={log.id}>
            <td>{log.name}</td>
            <td>{log.action}</td>
            <td>{log.details}</td>
            <td>{log.created_at}</td>
          </tr>
        ))}

        </tbody>

      </table>

    </MainLayout>

  );

}
