/*
Rôle du fichier :
Cette page affiche la liste des serveurs de l’utilisateur connecté.

Ce qu’il contient :
- le chargement des serveurs depuis l’API
- un affichage en cartes
- un état de chargement
- un message si aucun serveur n’existe

Pourquoi il existe :
Le projet doit fournir une page claire de gestion et de visualisation des serveurs surveillés.

Comment il s’intègre dans le projet :
Elle est accessible depuis le menu latéral du dashboard.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";
import ServerCard from "../components/ServerCard";

export default function ServersPage() {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadServers();
  }, []);

  const loadServers = async () => {
    try {
      const res = await client.get("/api/servers");
      setServers(res.data.data.servers || []);
    } catch (error) {
      console.error("Erreur chargement serveurs :", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <h1 style={styles.title}>Serveurs</h1>

      {loading && <div style={styles.info}>Chargement des serveurs...</div>}

      {!loading && servers.length === 0 && (
        <div style={styles.info}>Aucun serveur enregistré.</div>
      )}

      <div style={styles.grid}>
        {servers.map((server) => (
          <ServerCard key={server.id} server={server} />
        ))}
      </div>
    </MainLayout>
  );
}

const styles = {
  title: {
    marginBottom: "20px",
  },
  info: {
    background: "#fff",
    padding: "16px",
    borderRadius: "12px",
    marginBottom: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: "16px",
  },
};
