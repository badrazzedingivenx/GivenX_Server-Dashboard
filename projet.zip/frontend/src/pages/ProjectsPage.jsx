/*
Rôle du fichier :
Cette page affiche la liste des projets surveillés de l’utilisateur connecté.

Ce qu’il contient :
- le chargement des projets depuis l’API
- un affichage en cartes
- un état de chargement
- un message si aucun projet n’existe

Pourquoi il existe :
Le projet doit afficher les applications surveillées de manière lisible.

Comment il s’intègre dans le projet :
Elle est accessible depuis le menu latéral du dashboard.
*/

import React, { useEffect, useState } from "react";
import client from "../api/client";
import MainLayout from "../layout/MainLayout";
import ProjectCard from "../components/ProjectCard";

export default function ProjectsPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    try {
      const res = await client.get("/api/projects");
      setProjects(res.data.data.projects || []);
    } catch (error) {
      console.error("Erreur chargement projets :", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <h1 style={styles.title}>Projets</h1>

      {loading && <div style={styles.info}>Chargement des projets...</div>}

      {!loading && projects.length === 0 && (
        <div style={styles.info}>Aucun projet enregistré.</div>
      )}

      <div style={styles.grid}>
        {projects.map((project) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>
    </MainLayout>
  );
}

const styles = {
  title: {
    marginBottom: "20px",
  },
  info: {
    background: "#fff",
    padding: "16px",
    borderRadius: "12px",
    marginBottom: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: "16px",
  },
};
