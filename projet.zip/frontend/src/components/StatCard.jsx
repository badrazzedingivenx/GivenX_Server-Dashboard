/*
Rôle du fichier :
Ce composant affiche une carte de statistique dans le dashboard.

Ce qu’il contient :
- un titre
- une valeur principale
- une couleur de fond légère

Pourquoi il existe :
Le dashboard a besoin de cartes simples pour résumer rapidement les données.

Comment il s’intègre dans le projet :
DashboardPage utilise ce composant pour CPU, RAM, disque, alertes, etc.
*/

import React from "react";

export default function StatCard({ title, value }) {
  return (
    <div style={styles.card}>
      <div style={styles.title}>{title}</div>
      <div style={styles.value}>{value}</div>
    </div>
  );
}

const styles = {
  card: {
    background: "#fff",
    borderRadius: "12px",
    padding: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  title: {
    color: "#64748b",
    marginBottom: "10px",
  },
  value: {
    fontSize: "28px",
    fontWeight: "bold",
    color: "#0f172a",
  },
};
