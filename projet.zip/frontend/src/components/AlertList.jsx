/*
Rôle du fichier :
Ce composant affiche la liste des alertes.

Ce qu’il contient :
- une liste simple d’alertes
- le type
- la sévérité
- le message

Pourquoi il existe :
Le dashboard doit montrer rapidement les incidents détectés.

Comment il s’intègre dans le projet :
Utilisé dans DashboardPage et AlertsPage.
*/

import React from "react";

export default function AlertList({ alerts }) {
  if (!alerts || alerts.length === 0) {
    return <div style={styles.empty}>Aucune alerte.</div>;
  }

  return (
    <div style={styles.list}>
      {alerts.map((alert) => (
        <div key={alert.id} style={styles.item}>
          <div style={styles.top}>
            <strong>{alert.type}</strong>
            <span style={styles.badge}>{alert.severity}</span>
          </div>
          <div>{alert.message}</div>
        </div>
      ))}
    </div>
  );
}

const styles = {
  list: {
    display: "grid",
    gap: "12px",
  },
  item: {
    background: "#fff",
    borderRadius: "12px",
    padding: "16px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  top: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "8px",
  },
  badge: {
    background: "#fee2e2",
    color: "#b91c1c",
    padding: "4px 8px",
    borderRadius: "999px",
    fontSize: "12px",
  },
  empty: {
    background: "#fff",
    padding: "16px",
    borderRadius: "12px",
  },
};
