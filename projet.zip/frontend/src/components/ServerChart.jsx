/*
Rôle du fichier :
Ce composant affiche un graphique simple des métriques serveur.

Ce qu’il contient :
- une courbe CPU
- une courbe RAM
- une courbe disque

Pourquoi il existe :
Le dashboard doit visualiser l’évolution des métriques dans le temps.

Comment il s’intègre dans le projet :
DashboardPage utilise ce composant avec les données de l’historique serveur.
*/

import React from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function ServerChart({ data }) {
  return (
    <div style={styles.card}>
      <h3 style={styles.title}>Historique Serveur</h3>
      <div style={{ width: "100%", height: 320 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="collected_at" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="cpu_usage" name="CPU %" />
            <Line type="monotone" dataKey="ram_usage" name="RAM %" />
            <Line type="monotone" dataKey="disk_usage" name="Disque %" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const styles = {
  card: {
    background: "#fff",
    borderRadius: "12px",
    padding: "20px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
  },
  title: {
    marginBottom: "16px",
  },
};
