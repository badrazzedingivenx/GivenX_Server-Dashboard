/*
Rôle du fichier :
Ce fichier contient la structure visuelle principale de l’application.

Ce qu’il contient :
- une barre latérale de navigation
- un header utilisateur
- l’affichage conditionnel des liens admin
- le lien vers la page des logs

Pourquoi il existe :
Il assure une interface cohérente sur toutes les pages du dashboard.

Comment il s’intègre dans le projet :
Toutes les pages privées sont affichées dans ce layout.
*/

import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function MainLayout({ children }) {
  const { user, logout } = useAuth();

  return (
    <div style={styles.app}>
      <aside style={styles.sidebar}>
        <h2 style={styles.logo}>Monitoring SaaS</h2>

        <nav style={styles.nav}>
          <Link style={styles.link} to="/">Dashboard</Link>
          <Link style={styles.link} to="/servers">Serveurs</Link>
          <Link style={styles.link} to="/projects">Projets</Link>
          <Link style={styles.link} to="/alerts">Alertes</Link>
          <Link style={styles.link} to="/alert-rules">Règles alertes</Link>         
 <Link style={styles.link} to="/logs">Logs</Link>

          {user?.role === "admin" && (
            <>
              <Link style={styles.link} to="/admin">Administration</Link>
              <Link style={styles.link} to="/admin/users">Utilisateurs</Link>
            </>
          )}
        </nav>
      </aside>

      <main style={styles.main}>
        <header style={styles.header}>
          <div>
            <strong>{user?.name || "Utilisateur"}</strong>
            <div style={styles.email}>{user?.email}</div>
            <div style={styles.role}>Rôle : {user?.role}</div>
          </div>

          <button onClick={logout} style={styles.button}>
            Déconnexion
          </button>
        </header>

        <section>{children}</section>
      </main>
    </div>
  );
}

const styles = {
  app: {
    display: "flex",
    minHeight: "100vh",
    background: "#f4f7fb",
    fontFamily: "Arial, sans-serif",
  },
  sidebar: {
    width: "240px",
    background: "#1e293b",
    color: "#fff",
    padding: "24px 16px",
  },
  logo: {
    marginBottom: "24px",
    fontSize: "22px",
  },
  nav: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  link: {
    color: "#fff",
    textDecoration: "none",
    padding: "10px 12px",
    borderRadius: "8px",
    background: "#334155",
  },
  main: {
    flex: 1,
    padding: "24px",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: "#fff",
    padding: "16px 20px",
    borderRadius: "12px",
    marginBottom: "24px",
  },
  email: {
    color: "#64748b",
    fontSize: "14px",
  },
  role: {
    color: "#2563eb",
    fontSize: "13px",
    marginTop: "4px",
  },
  button: {
    background: "#dc2626",
    color: "#fff",
    border: "none",
    padding: "10px 14px",
    borderRadius: "8px",
    cursor: "pointer",
  },
};
